declare namespace _default {
    const ADD: string;
    const REMOVE: string;
}
export default _default;
//# sourceMappingURL=CollectionEventType.d.ts.map