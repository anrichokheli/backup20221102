declare namespace _default {
    const ACTIVE: string;
}
export default _default;
//# sourceMappingURL=Property.d.ts.map