declare namespace _default {
    const LEFT: number;
    const UP: number;
    const RIGHT: number;
    const DOWN: number;
}
export default _default;
//# sourceMappingURL=KeyCode.d.ts.map