export default OWS;
declare class OWS extends XML {
}
import XML from "./XML.js";
//# sourceMappingURL=OWS.d.ts.map